import React from 'react';

const IconWrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <div className="w-6 h-6 flex items-center justify-center text-text-secondary">{children}</div>
);

// --- Icon Components (self-contained for the library, updated to accept className) ---
const TimeIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.414-1.415L11 9.586V6z" clipRule="evenodd" /></svg>);
const DistanceIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" /></svg>);
const AlphabeticalSortIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M4.5 14.5L6.5 4.5L8.5 14.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M5 11.5H8" strokeLinecap="round" strokeLinejoin="round"/><path d="M11.5 14.5V4.5L15.5 14.5V4.5" strokeLinecap="round" strokeLinejoin="round"/></svg>);
const SortIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M3 4.5h14.25M3 9h9.75M3 13.5h5.25m5.25-.75L17.25 9m0 0L21 12.75M17.25 9v12" /></svg>);
const FilterIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M12 3v18m-8-8h16" /><path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 18h16" /></svg>);
const PriceIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M10 18a4.4183 4.4183 0 000-8.8366M10 2a4.4183 4.4183 0 000 8.8366M10 18a4.4183 4.4183 0 010-8.8366M10 2a4.4183 4.4183 0 010 8.8366M12.25 7.25H9.5C8.40294 7.25 7.5 8.15294 7.5 9.25v1C7.5 11.3471 8.40294 12.25 9.5 12.25h1c1.0971 0 2 .8954 2 2v.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M10 6V15" strokeLinecap="round" strokeLinejoin="round"/></svg>);
const AccessIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M15.5 10.5V4.5C15.5 3.67157 14.8284 3 14 3H6C5.17157 3 4.5 3.67157 4.5 4.5v11C4.5 16.3284 5.17157 17 6 17h4.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M13.5 13.5L17.5 17.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M17.5 13.5L13.5 17.5" strokeLinecap="round" strokeLinejoin="round"/></svg>);
const EventTypeIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M17 12c0 2.7614-3.134 5-7 5s-7-2.2386-7-5c0-2.7614 3.134-5 7-5s7 2.2386 7 5z" strokeLinecap="round" strokeLinejoin="round"/><path d="M5.5 5.5h9c.8284 0 1.5.6716 1.5 1.5V7.5" strokeLinecap="round" strokeLinejoin="round"/></svg>);
const DietIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M15 15.5S12 17 10 17 5 15.5 5 15.5C5 12.5 10 2.5 10 2.5S15 12.5 15 15.5z" strokeLinecap="round" strokeLinejoin="round"/></svg>);
const ChevronLeftIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" /></svg>);
const ReligiousIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9 4a1 1 0 011-1h.01a1 1 0 011 1v4h3a1 1 0 110 2h-3v7a1 1 0 11-2 0V9H6a1 1 0 110-2h3V4z" clipRule="evenodd" /></svg>);
const CommunityIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="currentColor"><path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z" /></svg>);
const FoodBankIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="currentColor"><path d="M5 8a1 1 0 011-1h8a1 1 0 110 2H6a1 1 0 01-1-1z" /><path fillRule="evenodd" d="M4 4a2 2 0 012-2h8a2 2 0 012 2v12a2 2 0 01-2-2H6a2 2 0 01-2-2V4zm2 0v12h8V4H6z" clipRule="evenodd" /></svg>);
const InfoIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" /></svg>);
const CalendarIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" /></svg>);
const LinkIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M12.586 4.586a2 2 0 112.828 2.828l-3 3a2 2 0 01-2.828 0 1 1 0 00-1.414 1.414 4 4 0 005.656 0l3-3a4 4 0 00-5.656-5.656l-1.5 1.5a1 1 0 101.414 1.414l1.5-1.5zm-5 5a2 2 0 012.828 0 1 1 0 101.414-1.414 4 4 0 00-5.656 0l-3 3a4 4 0 105.656 5.656l1.5-1.5a1 1 0 10-1.414-1.414l-1.5 1.5a2 2 0 11-2.828-2.828l3-3z" clipRule="evenodd" /></svg>);
const TagIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M17.707 9.293a1 1 0 010 1.414l-7 7a1 1 0 01-1.414 0l-7-7A1 1 0 012 10V5a1 1 0 011-1h5a1 1 0 01.707.293l7 7zM5 6a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" /></svg>);
const RepeatIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 110 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clipRule="evenodd" /></svg>);
const EditIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="currentColor"><path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" /><path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" /></svg>);
const DeleteIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" /></svg>);
const ExternalLinkIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>);
const ModalIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9.75 6.75h4.5m-4.5 10.5h4.5m-7.5-5.25h10.5a2.25 2.25 0 002.25-2.25V6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v10.5a2.25 2.25 0 002.25 2.25z" /></svg>);
const PanelIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="15" y1="3" x2="15" y2="21"></line></svg>);
const TargetIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><circle cx="12" cy="12" r="10" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12h.01M12 12h.01M9 12h.01M12 9v.01M12 15v.01" /></svg>);
const EmailIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="currentColor"><path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" /><path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" /></svg>);
const PhoneIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="currentColor"><path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" /></svg>);
const AccessLevelWalkInIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>);
const AccessLevelRegIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L15.232 5.232z" /></svg>);
const AccessLevelRefIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>);
const CostFreeIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7" /></svg>);
const CostPaidIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v.01M12 12v-2m0 2v.01M12 12a2 2 0 100 4 2 2 0 000-4zm0 0H9.571m2.429 0H12m0 0H9.571m2.429 0A2.5 2.5 0 0112 14.5m0 0V12m0 2.5a2.5 2.5 0 01-2.5-2.5M12 14.5A2.5 2.5 0 0014.5 12m0 0h2.429" /></svg>);
const DietaryVegIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547a2 2 0 00-.547 1.806l.477 2.387a6 6 0 00.517 3.86l.158.318a6 6 0 00.517 3.86l2.387.477a2 2 0 001.806-.547a2 2 0 00.547-1.806l-.477-2.387a6 6 0 00-.517-3.86l-.158-.318a6 6 0 00-.517-3.86l-2.387-.477A2 2 0 005.21 6.05l2.387.477a6 6 0 003.86-.517l.318-.158a6 6 0 013.86-.517l2.387-.477a2 2 0 001.806-.547 2 2 0 00.547-1.806l-.477-2.387a6 6 0 00-.517-3.86l-.158-.318a6 6 0 00-.517-3.86L18.79 4.21a2 2 0 00-1.806-.547 2 2 0 00-.547 1.806l.477 2.387a6 6 0 00.517 3.86l.158.318a6 6 0 00.517 3.86l2.387.477a2 2 0 001.022-.547z" /></svg>);
const DietaryHalalIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M21.752 15.002A9.718 9.718 0 0118 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 003 11.25C3 16.635 7.365 21 12.75 21a9.753 9.753 0 009.002-5.998z" /></svg>);
const BreakPatternIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 24 24" fill="none"><path d="M8 3L4 9L8 15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/><path d="M16 3L20 9L16 15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>);
const EyeIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z" /><path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.022 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" /></svg>);
const AddIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" /></svg>);
const SpinnerIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={`${className} animate-spin`} fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>);
const WarningIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M8.257 3.099c.636-1.21 2.242-1.21 2.878 0l5.394 10.273c.636 1.21-.213 2.628-1.439 2.628H4.302c-1.226 0-2.075-1.418-1.439-2.628L8.257 3.099zM10 6a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 6zm0 8a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" /></svg>);
const CloseIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>);
const ImportIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>);
const ExportIcon: React.FC<{ className?: string }> = ({ className }) => (<svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>);

const iconData = [
    { name: 'Sort (Time)', icon: <TimeIcon />, usedIn: 'Header, Filter Bar', functionality: 'Triggers sorting events/venues by time (active first, then upcoming).', states: [{name: 'Default', icon: <TimeIcon className="w-5 h-5 text-text-secondary"/>}, {name: 'Active', icon: <TimeIcon className="w-5 h-5 text-accent"/>}] },
    { name: 'Sort (Distance)', icon: <DistanceIcon />, usedIn: 'Header, Filter Bar', functionality: 'Triggers sorting venues by distance from the user.', states: [{name: 'Default', icon: <DistanceIcon className="w-5 h-5 text-text-secondary"/>}, {name: 'Active', icon: <DistanceIcon className="w-5 h-5 text-accent"/>}] },
    { name: 'Sort (Alphabetical)', icon: <AlphabeticalSortIcon />, usedIn: 'Header, Filter Bar', functionality: 'Triggers sorting venues alphabetically by name.', states: [{name: 'Default', icon: <AlphabeticalSortIcon className="w-5 h-5 text-text-secondary"/>}, {name: 'Active', icon: <AlphabeticalSortIcon className="w-5 h-5 text-accent"/>}] },
    { name: 'Sort (Default)', icon: <SortIcon />, usedIn: 'Header, Filter Bar', functionality: 'Default icon for the sort button before user interaction.', states: [{name: 'Default', icon: <SortIcon className="w-5 h-5 text-text-secondary"/>}] },
    { name: 'Filter', icon: <FilterIcon />, usedIn: 'Header', functionality: 'Opens the main filter dropdown or toggles the inline filter bar.', states: [{name: 'Default', icon: <FilterIcon className="w-5 h-5 text-text-secondary"/>}, {name: 'Active', icon: <FilterIcon className="w-5 h-5 text-accent"/>}] },
    { name: 'Filter (Price)', icon: <PriceIcon />, usedIn: 'Inline Filter Bar', functionality: 'Opens popover to filter events by cost.', states: [{name: 'Default', icon: <PriceIcon className="w-5 h-5 text-text-secondary"/>}, {name: 'Active', icon: <PriceIcon className="w-5 h-5 text-accent"/>}] },
    { name: 'Filter (Access)', icon: <AccessIcon />, usedIn: 'Inline Filter Bar', functionality: 'Opens popover to filter events by access level.', states: [{name: 'Default', icon: <AccessIcon className="w-5 h-5 text-text-secondary"/>}, {name: 'Active', icon: <AccessIcon className="w-5 h-5 text-accent"/>}] },
    { name: 'Filter (Event Type)', icon: <EventTypeIcon />, usedIn: 'Inline Filter Bar', functionality: 'Opens popover to filter by meals or packages.', states: [{name: 'Default', icon: <EventTypeIcon className="w-5 h-5 text-text-secondary"/>}, {name: 'Active', icon: <EventTypeIcon className="w-5 h-5 text-accent"/>}] },
    { name: 'Filter (Diet)', icon: <DietIcon />, usedIn: 'Inline Filter Bar', functionality: 'Opens popover to filter by dietary needs (e.g., vegan).', states: [{name: 'Default', icon: <DietIcon className="w-5 h-5 text-text-secondary"/>}, {name: 'Active', icon: <DietIcon className="w-5 h-5 text-accent"/>}] },
    { name: 'View Mode', icon: <EyeIcon />, usedIn: 'Header', functionality: 'Opens dropdown to switch between Timeline, List, and Grid views.', states: [{name: 'Default', icon: <EyeIcon className="w-5 h-5 text-text-secondary"/>}, {name: 'Open', icon: <EyeIcon className="w-5 h-5 text-white"/>}] },
    { name: 'Venue (Religious)', icon: <ReligiousIcon />, usedIn: 'Venue Card', functionality: 'Identifies a venue as a religious organization.', states: [{name: 'Default', icon: <ReligiousIcon className="w-5 h-5 text-red-800"/>}] },
    { name: 'Venue (Community)', icon: <CommunityIcon />, usedIn: 'Venue Card', functionality: 'Identifies a venue as a community or social organization.', states: [{name: 'Default', icon: <CommunityIcon className="w-5 h-5 text-green-800"/>}] },
    { name: 'Venue (Food Bank)', icon: <FoodBankIcon />, usedIn: 'Venue Card', functionality: 'Identifies a venue as a food bank.', states: [{name: 'Default', icon: <FoodBankIcon className="w-5 h-5 text-blue-800"/>}] },
    { name: 'Location Pin', icon: <DistanceIcon />, usedIn: 'Venue Card, Event Detail', functionality: 'Indicates location or distance information.', states: [{name: 'Default', icon: <DistanceIcon className="w-5 h-5 text-accent"/>}] },
    { name: 'Time / Clock', icon: <TimeIcon />, usedIn: 'Event Detail, Header', functionality: 'Indicates time, date, or duration. Also used for time view dropdown.', states: [{name: 'Default', icon: <TimeIcon className="w-5 h-5 text-text-secondary"/>}] },
    { name: 'Information', icon: <InfoIcon />, usedIn: 'Event Detail', functionality: 'Header icon for the "About" section.', states: [{name: 'Default', icon: <InfoIcon className="w-5 h-5 text-text-secondary"/>}] },
    { name: 'Calendar', icon: <CalendarIcon />, usedIn: 'Event Detail, Event List', functionality: 'Indicates date or registration deadline information.', states: [{name: 'Default', icon: <CalendarIcon className="w-5 h-5 text-text-secondary"/>}] },
    { name: 'External Link', icon: <LinkIcon />, usedIn: 'Event Detail', functionality: 'Indicates a link to an external source URL.', states: [{name: 'Default', icon: <LinkIcon className="w-5 h-5 text-text-secondary"/>}, {name: 'Hover', icon: <LinkIcon className="w-5 h-5 text-text-primary"/>}] },
    { name: 'Dietary Tag', icon: <TagIcon />, usedIn: 'Event Detail', functionality: 'Header icon for the "Dietary Needs" section.', states: [{name: 'Default', icon: <TagIcon className="w-5 h-5 text-text-secondary"/>}] },
    { name: 'Access Level', icon: <CommunityIcon />, usedIn: 'Event Detail', functionality: 'Indicates the access level (e.g., Walk-in).', states: [{name: 'Default', icon: <CommunityIcon className="w-5 h-5 text-text-secondary"/>}] },
    { name: 'Recurrence', icon: <RepeatIcon />, usedIn: 'Event Detail', functionality: 'Indicates that an event is recurring and shows the next date.', states: [{name: 'Default', icon: <RepeatIcon className="w-5 h-5 text-text-secondary"/>}] },
    { name: 'Edit', icon: <EditIcon />, usedIn: 'Admin, Event Detail', functionality: 'Opens the form to edit an item.', states: [{name: 'Default', icon: <EditIcon className="w-5 h-5 text-text-secondary"/>}, {name: 'Hover', icon: <EditIcon className="w-5 h-5 text-blue-600"/>}] },
    { name: 'Delete', icon: <DeleteIcon />, usedIn: 'Admin, Event Detail', functionality: 'Initiates the deletion of an item.', states: [{name: 'Default', icon: <DeleteIcon className="w-5 h-5 text-text-secondary"/>}, {name: 'Hover', icon: <DeleteIcon className="w-5 h-5 text-accent"/>}] },
    { name: 'Registration (URL)', icon: <TargetIcon />, usedIn: 'Event Detail', functionality: 'A button to register via a website link.', states: [{name: 'Default', icon: <TargetIcon className="w-5 h-5 text-accent"/>}] },
    { name: 'Registration (Email)', icon: <EmailIcon />, usedIn: 'Event Detail', functionality: 'A button to register via email.', states: [{name: 'Default', icon: <EmailIcon className="w-5 h-5 text-accent"/>}] },
    { name: 'Registration (Phone)', icon: <PhoneIcon />, usedIn: 'Event Detail', functionality: 'A button to register via phone call.', states: [{name: 'Default', icon: <PhoneIcon className="w-5 h-5 text-accent"/>}] },
    { name: 'Access (Walk-In)', icon: <AccessLevelWalkInIcon />, usedIn: 'Event List', functionality: 'Indicates an event requires no registration.', states: [{name: 'Default', icon: <AccessLevelWalkInIcon className="w-5 h-5 text-gray-800"/>}] },
    { name: 'Access (Registration)', icon: <AccessLevelRegIcon />, usedIn: 'Event List', functionality: 'Indicates an event requires registration.', states: [{name: 'Default', icon: <AccessLevelRegIcon className="w-5 h-5 text-gray-800"/>}] },
    { name: 'Access (Referral)', icon: <AccessLevelRefIcon />, usedIn: 'Event List', functionality: 'Indicates an event requires a referral.', states: [{name: 'Default', icon: <AccessLevelRefIcon className="w-5 h-5 text-gray-800"/>}] },
    { name: 'Cost (Free)', icon: <CostFreeIcon />, usedIn: 'Event List', functionality: 'Indicates an event is free of charge.', states: [{name: 'Default', icon: <CostFreeIcon className="w-5 h-5 text-gray-800"/>}] },
    { name: 'Cost (Paid)', icon: <CostPaidIcon />, usedIn: 'Event List', functionality: 'Indicates an event has a cost.', states: [{name: 'Default', icon: <CostPaidIcon className="w-5 h-5 text-gray-800"/>}] },
    { name: 'Diet (Veg/Vegan)', icon: <DietaryVegIcon />, usedIn: 'Event List', functionality: 'Indicates vegetarian or vegan options.', states: [{name: 'Default', icon: <DietaryVegIcon className="w-5 h-5 text-green-800"/>}] },
    { name: 'Diet (Halal)', icon: <DietaryHalalIcon />, usedIn: 'Event List', functionality: 'Indicates halal options.', states: [{name: 'Default', icon: <DietaryHalalIcon className="w-5 h-5 text-green-800"/>}] },
    { name: 'Expand/Collapse', icon: <ChevronLeftIcon />, usedIn: 'Timeline Header', functionality: 'Expands or collapses the venue column.', states: [{name: 'Default', icon: <ChevronLeftIcon className="w-5 h-5 text-text-secondary"/>}] },
    { name: 'Collapsed Timeline', icon: <BreakPatternIcon />, usedIn: 'Timeline Header', functionality: 'Indicates a collapsed, inactive time segment.', states: [{name: 'Default', icon: <BreakPatternIcon className="w-5 h-5 text-gray-300"/>}] },
    { name: 'Add New', icon: <AddIcon />, usedIn: 'Header, Admin', functionality: 'Opens the form to add a new event or venue.', states: [{name: 'Default', icon: <AddIcon className="w-5 h-5 text-white"/>}] },
    { name: 'Loading Spinner', icon: <SpinnerIcon />, usedIn: 'Geolocation Bar', functionality: 'Indicates that the location is being fetched.', states: [{name: 'Default', icon: <SpinnerIcon className="w-5 h-5 text-gray-500"/>}] },
    { name: 'Warning', icon: <WarningIcon />, usedIn: 'Geolocation Bar', functionality: 'Indicates an error in fetching the location.', states: [{name: 'Default', icon: <WarningIcon className="w-5 h-5 text-yellow-600"/>}] },
    { name: 'Close', icon: <CloseIcon />, usedIn: 'Modals, Detail Panels', functionality: 'Closes the current modal or panel.', states: [{name: 'Default', icon: <CloseIcon className="w-5 h-5 text-text-secondary"/>}, {name: 'Hover', icon: <CloseIcon className="w-5 h-5 text-text-primary"/>}] },
    { name: 'Import', icon: <ImportIcon />, usedIn: 'Admin', functionality: 'Opens file picker to import data.', states: [{name: 'Default', icon: <ImportIcon className="w-5 h-5 text-text-secondary"/>}] },
    { name: 'Export', icon: <ExportIcon />, usedIn: 'Admin', functionality: 'Downloads all data as a JSON file.', states: [{name: 'Default', icon: <ExportIcon className="w-5 h-5 text-text-secondary"/>}] },
    { name: 'View as Modal', icon: <ModalIcon />, usedIn: 'Event Detail', functionality: 'Changes the detail panel view to a centered modal.', states: [{name: 'Default', icon: <ModalIcon className="w-5 h-5 text-text-secondary"/>}, {name: 'Hover', icon: <ModalIcon className="w-5 h-5 text-text-primary"/>}] },
    { name: 'View as Panel', icon: <PanelIcon />, usedIn: 'Event Detail', functionality: 'Changes the detail modal view to a side panel.', states: [{name: 'Default', icon: <PanelIcon className="w-5 h-5 text-text-secondary"/>}, {name: 'Hover', icon: <PanelIcon className="w-5 h-5 text-text-primary"/>}] },
];

export const IconLibrary: React.FC = () => {
    const handleExport = () => {
        const dataToExport = iconData.map(item => ({
            name: item.name,
            functionality: item.functionality,
            usedIn: item.usedIn,
            // Cannot serialize React components directly, so we export metadata
            // including the component's display name. For a full AI evaluation,
            // storing the raw SVG strings in iconData would be the next step.
            componentName: (item.icon.type as React.FC).displayName || (item.icon.type as React.FC).name || 'Unknown',
            states: item.states.map(s => ({
                name: s.name,
                componentName: (s.icon.type as React.FC).displayName || (s.icon.type as React.FC).name || 'Unknown',
            })),
        }));

        const jsonString = JSON.stringify(dataToExport, null, 2);
        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
    
        const a = document.createElement('a');
        a.href = url;
        a.download = `icon-library-data-${new Date().toISOString().slice(0, 10)}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    return (
        <div className="bg-white p-4 md:p-6 rounded-lg shadow-sm border border-border-color">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-6">
                <div>
                    <h2 className="text-xl font-bold text-text-primary">Icon Library</h2>
                    <p className="text-sm text-text-secondary mt-1">A reference for all custom icons used in the application.</p>
                </div>
                <button
                    onClick={handleExport}
                    className="flex items-center self-start sm:self-center space-x-2 px-4 py-2 text-sm font-medium rounded-md border border-border-color text-text-secondary bg-white hover:bg-surface transition-colors"
                >
                    <ExportIcon className="w-5 h-5" />
                    <span>Export as JSON</span>
                </button>
            </div>
            <div className="overflow-x-auto">
                <table className="min-w-full text-sm">
                    <thead className="bg-surface">
                        <tr>
                            <th scope="col" className="px-4 py-3 text-left font-semibold text-text-secondary w-16">Icon</th>
                            <th scope="col" className="px-4 py-3 text-left font-semibold text-text-secondary">Name</th>
                            <th scope="col" className="px-4 py-3 text-left font-semibold text-text-secondary">Place</th>
                            <th scope="col" className="px-4 py-3 text-left font-semibold text-text-secondary">States</th>
                        </tr>
                    </thead>
                    {iconData.map((item, index) => (
                        <tbody key={index} className="border-t border-border-color hover:bg-surface/50 transition-colors">
                            <tr>
                                <td className="px-4 pt-3 pb-1 align-top">
                                    <IconWrapper>{item.icon}</IconWrapper>
                                </td>
                                <td className="px-4 pt-3 pb-1 align-top font-medium text-text-primary">{item.name}</td>
                                <td className="px-4 pt-3 pb-1 align-top text-text-secondary">{item.usedIn}</td>
                                <td className="px-4 pt-3 pb-1 align-top">
                                    <div className="flex items-center gap-3 flex-wrap">
                                        {item.states.map((state, stateIndex) => (
                                            <div key={stateIndex} className="flex flex-col items-center p-1 text-center" title={state.name}>
                                                <div className="w-5 h-5 mb-1">{state.icon}</div>
                                                <span className="text-[10px] text-text-secondary">{state.name}</span>
                                            </div>
                                        ))}
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td colSpan={4} className="px-4 pb-3 text-xs text-text-secondary">
                                    {item.functionality}
                                </td>
                            </tr>
                        </tbody>
                    ))}
                </table>
            </div>
        </div>
    );
};
