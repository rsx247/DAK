import React from 'react';

// --- Sort Icons ---
export const TimeIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} viewBox="0 0 20 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
        <path fillRule="evenodd" clipRule="evenodd" d="M10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2C5.58172 2 2 5.58172 2 10C2 14.4183 5.58172 18 10 18ZM10.5 5.75C10.5 5.33579 10.1642 5 9.75 5C9.33579 5 9 5.33579 9 5.75V10.25C9 10.4371 9.07353 10.6158 9.20599 10.7483L12.456 14.0015C12.7488 14.2946 13.2236 14.2948 13.5166 14.002C13.8095 13.7092 13.8093 13.2343 13.5164 12.9414L10.5 9.92132V5.75Z" />
    </svg>
);

export const DistanceIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} viewBox="0 0 20 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
        <path fillRule="evenodd" clipRule="evenodd" d="M10 18C10 18 5 13.5817 5 10C5 6.41828 7.23858 4 10 4C12.7614 4 15 6.41828 15 10C15 13.5817 10 18 10 18ZM10 12C11.1046 12 12 11.1046 12 10C12 8.89543 11.1046 8 10 8C8.89543 8 8 8.89543 8 10C8 11.1046 8.89543 12 10 12Z" />
        <circle cx="10" cy="1" r="1" />
    </svg>
);

// --- Filter Icons ---
export const PriceIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5" xmlns="http://www.w3.org/2000/svg">
         <path d="M10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2C5.58172 2 2 5.58172 2 10C2 14.4183 5.58172 18 10 18Z" strokeLinecap="round" strokeLinejoin="round"/>
         <path d="M12.25 7.25H9.5C8.40294 7.25 7.5 8.15294 7.5 9.25V10.25C7.5 11.3471 8.40294 12.25 9.5 12.25H10.5C11.5971 12.25 12.5 13.1529 12.5 14.25V14.75" strokeLinecap="round" strokeLinejoin="round"/>
         <path d="M10 6V15" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

export const AccessIcon: React.FC<{ className?: string }> = ({ className }) => (
     <svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5" xmlns="http://www.w3.org/2000/svg">
        <path d="M15.5 10.5L15.5 4.5C15.5 3.67157 14.8284 3 14 3H6C5.17157 3 4.5 3.67157 4.5 4.5V15.5C4.5 16.3284 5.17157 17 6 17H10.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M13.5 13.5L17.5 17.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M17.5 13.5L13.5 17.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

export const EventTypeIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5" xmlns="http://www.w3.org/2000/svg">
        <path d="M17 12C17 14.7614 13.866 17 10 17C6.13401 17 3 14.7614 3 12C3 9.23858 6.13401 7 10 7C13.866 7 17 9.23858 17 12Z" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M5.5 5.5H14.5C15.3284 5.5 16 6.17157 16 7V7.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

export const DietIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5" xmlns="http://www.w3.org/2000/svg">
        <path d="M15 15.5C15 15.5 12 17 10 17C8 17 5 15.5 5 15.5C5 12.5 10 2.5 10 2.5C10 2.5 15 12.5 15 15.5Z" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

// --- Utility Icons ---
export const CheckIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} viewBox="0 0 20 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
        <path fillRule="evenodd" clipRule="evenodd" d="M10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2C5.58172 2 2 5.58172 2 10C2 14.4183 5.58172 18 10 18ZM13.7071 8.70711C14.0976 8.31658 14.0976 7.68342 13.7071 7.29289C13.3166 6.90237 12.6834 6.90237 12.2929 7.29289L9 10.5858L7.70711 9.29289C7.31658 8.90237 6.68342 8.90237 6.29289 9.29289C5.90237 9.68342 5.90237 10.3166 6.29289 10.7071L8.29289 12.7071C8.68342 13.0976 9.31658 13.0976 9.70711 12.7071L13.7071 8.70711Z" />
    </svg>
);

export const ChevronLeftIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
    </svg>
);
