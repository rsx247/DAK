# Icon Changes

Old Icon → New Icon

TimeIcon - Old Icon → New Icon

DistanceIcon - Old Icon → New Icon

PriceIcon - Old Icon → New Icon

AccessIcon - Old Icon → New Icon

ClockIcon - Old Icon → New Icon

CalendarIcon - Old Icon → New Icon

PinIcon - Old Icon → New Icon

CostIcon - Old Icon → New Icon

PhoneIcon - Old Icon → New Icon

EmailIcon - Old Icon → New Icon

LinkIcon - Old Icon → New Icon

SaladIcon - Old Icon → New Icon

RecurrenceIcon - Old Icon → New Icon

ReligiousIcon - Old Icon → New Icon

CommunityIcon - Old Icon → New Icon

FoodBankIcon - Old Icon → New Icon

SpinnerIcon - Old Icon → New Icon

GpsTrackingIcon - Old Icon → New Icon
